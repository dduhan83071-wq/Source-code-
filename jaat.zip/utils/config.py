import os

TOKEN = os.environ.get("TOKEN")
NAME = "moon"
server = "https://discord.gg/v5kCHhDKmE" # server 
OWNER_IDS = [1258831252748894436, 1430557850312249504] # user id of owner
BotName = "moon"
serverLink = "https://discord.gg/v5kCHhDKmE"
webhook_url = "https://discord.com/api/webhooks/1429019516326776895/jK2zm43KfDQ9FfC3wXaYSJt_ySFRNxITCf48NgpO8NxD8lxy3ujPjhlNpsjlT7wR5VbV" # webhook
power = "Powered by Moon Development™" # for embeds
invite = "https://discord.com/oauth2/authorize?client_id=1392040447576248322&permissions=8&integration_type=0&scope=bot+applications.commands" # url to invite bot
bot_id = "12345678" # bot user id 
np_channel1 = 1438922119911178422 # no prefix logs[when user is added]
np_channel2 = 1438922120024428724 # no prefix logs[when user is expired/removed]
website = "https://moon-hosting-ecru.vercel.app/"
ch = 1438922120749907989