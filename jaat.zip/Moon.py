import os
import asyncio
import traceback
from threading import Thread

import aiohttp
import discord
from discord.ext import commands
from dotenv import load_dotenv
from flask import Flask

# ===== LOAD ENV =====
load_dotenv()
TOKEN = os.getenv("TOKEN")

if not TOKEN:
    raise RuntimeError("❌ TOKEN not found. Please set TOKEN in .env file")

# ===== CORE IMPORTS =====
from core import Context
from core.Cog import Cog
from core.moon import moon
from utils.Tools import *
from utils.config import *

import jishaku
import cogs

# ===== JISHAKU SETTINGS =====
os.environ["JISHAKU_NO_DM_TRACEBACK"] = "False"
os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_FORCE_PAGINATOR"] = "True"

# ===== BOT INIT =====
client = moon()
tree = client.tree

# ===== EVENTS =====
@client.event
async def on_ready():
    await client.wait_until_ready()

    print("""
\033[1;31m
 ▄████▄   ▒█████  ▓█████▄ ▓█████ ▒██   ██▒
▒██▀ ▀█  ▒██▒  ██▒▒██▀ ██▌▓█   ▀ ▒▒ █ █ ▒░
▒▓█    ▄ ▒██░  ██▒░██   █▌▒███   ░░  █   ░
▒▓▓▄ ▄██▒▒██   ██░░▓█▄   ▌▒▓█  ▄  ░ █ █ ▒ 
▒ ▓███▀ ░░ ████▓▒░░▒████▓ ░▒████▒▒██▒ ▒██▒
\033[0m
""")

    print("✅ Loaded & Online!")
    print(f"🤖 Logged in as: {client.user}")
    print(f"🏠 Guilds: {len(client.guilds)}")
    print(f"👥 Users: {len(client.users)}")

    try:
        synced = await tree.sync()
        print(f"🔁 Synced {len(synced)} Slash Commands")
    except Exception as e:
        print("❌ Sync error:", e)

# ===== COMMAND LOGGER =====
@client.event
async def on_command_completion(ctx: commands.Context):
    if ctx.author.bot:
        return

    try:
        async with aiohttp.ClientSession() as session:
            webhook = discord.Webhook.from_url(webhook_url, session=session)

            embed = discord.Embed(color=0x000000)
            avatar = ctx.author.display_avatar.url

            embed.set_author(
                name=f"Command Used: {ctx.command}",
                icon_url=avatar
            )

            embed.add_field(
                name="User",
                value=f"{ctx.author} (`{ctx.author.id}`)",
                inline=False
            )

            if ctx.guild:
                embed.add_field(
                    name="Guild",
                    value=f"{ctx.guild.name} (`{ctx.guild.id}`)",
                    inline=False
                )
                embed.add_field(
                    name="Channel",
                    value=f"{ctx.channel.name}",
                    inline=False
                )

            embed.timestamp = discord.utils.utcnow()
            embed.set_footer(text=power, icon_url=client.user.display_avatar.url)

            await webhook.send(embed=embed)

    except Exception:
        traceback.print_exc()

# ===== FLASK KEEP ALIVE (OPTIONAL) =====
app = Flask(__name__)

@app.route("/")
def home():
    return "Moon Development™ 2025"

def run_flask():
    app.run(host="0.0.0.0", port=8080)

def keep_alive():
    Thread(target=run_flask, daemon=True).start()

keep_alive()

# ===== MAIN =====
async def main():
    async with client:
        await client.load_extension("jishaku")
        await client.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())