import discord
from discord.ext import commands
import asyncio
from utils.config import OWNER_IDS

class React(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return
        for owner in self.bot.owner_ids:
            if f"<@{owner}>" in message.content:
                try:
                    if owner == OWNER_IDS:
                        
                        emojis = [
                            "<a:owner:1435530390725984348>",
                            "<:7club_ban:1435530589557227530>",
                            "<:land_yildiz:1435530694708301825>",
                            "<a:_rose:1435530766208466973>",
                            "<:land_yildiz:1435530857812328560>",
                            "<a:37496alert:1435530945557168220>",
                            "<:sq_HeadMod:1435531020471635989>",
                            "<:Dc_RedCrownEsports:1435531096191406183>",
                            "<a:GIFD:1435531181507608588>",
                            "<a:GIFN:1435531266475692122>",
                            "<a:max__A:1435531345378938912>",
                            "<:Heeriye:1435533396645380197>",
                            "<:heart_em:1435533541990727731>",
                            "<a:Star:1435533605844680818>",
                            "<a:king:1435533707799953468>",
                            "<:headmod:1435533796878319688>",
                            "<a:sg_rd:1435533873919430686>",
                            "<a:RedHeart:1435533948745678848>",
                            "<a:star:1435534020363686028>"
                        ]
                        for emoji in emojis:
                            await message.add_reaction(emoji)
                    else:
                        
                        await message.add_reaction("<a:owner:1435530390725984348>")
                except discord.errors.RateLimited as e:
                    await asyncio.sleep(e.retry_after)
                    await message.add_reaction("<a:owner:1435530390725984348>")
                except Exception as e:
                    print(f"An unexpected error occurred Auto react owner mention: {e}")
