import discord
from discord.ext import commands

# Assuming a standard commands.Cog class since the base was not provided
class _owner(commands.Cog): 
    def __init__(self, bot):
        self.bot = bot

    """Owner commands"""

    # 1. Defines the field's look on the MAIN help page
    def help_custom(self):
        emoji = '👑'
        label = "Owner"
        description = "Commands only accessible to the bot owner."
        return emoji, label, description

    # 2. The docstring lists the commands for the help embed
    @commands.group(name="__Owner__", invoke_without_command=True)
    async def __Owner__(self, ctx: commands.Context):
        """
        `shutdown` , `reload` , `load` , `unload` , `eval` , `exec` , `blacklist add` , `blacklist remove`
        
        This docstring is what populates the '👑 Owner' field value.
        """
        # This function is the empty placeholder and does nothing else.
        if ctx.invoked_subcommand is None:
            pass 
            
# Standard cog setup function
async def setup(bot):
    await bot.add_cog(_owner(bot))